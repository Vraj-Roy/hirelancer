import { useEffect, useState } from "react";
import  Link from 'next/link';

const Assignment = ({assignmentName,createdAt,description,dueDate,postedBy, Slug, tags ,dueTime})=>{
    const [date,setDate]=useState("");
    const [newDuedate,setNewDueDate]=useState("");
    useEffect(() => {    
        var d=new Date(createdAt*1)  
        setDate((
            d.getDate()+
            "/"+(d.getMonth()+1)+
            "/"+(d.getFullYear())).toString() ); 

            if(dueDate){
                const [y, m, date] = dueDate.split("-") 
                setNewDueDate(`${date}/${m}/${y}`) 
            }
    }, []) 
    
     
    return(
        <>
        <Link href={Slug==""?("#"):(`/assignments/`+Slug)    }>
        <div className="cursor-pointer">

         <div className="  mx-5 w-full md:max-w-[900px] p-2 md:p-8 shadow-md md:mx-auto border-2 border-orange-300 rounded-md my-5">
            <div className="text-gray-700 my-2" >Posted on <span className="font-semibold text-md ml-1 text-gray-900"> {date} </span>  </div>
            <div className="text-gray-700 my-2" >Due on <span className="font-semibold text-md ml-1 text-gray-900"><span className="text-bold underline"> {newDuedate} </span>  on <span className="text-bold underline">{dueTime} </span></span>  </div>
            <div className="flex justify-between items-center my-2" >
            <div className="text-orange-600 text-xl font-semibold "> {assignmentName}  </div>
            <div className="hidden md:block "> 
            <button 
            type="button" 
            className="inline-block px-4 py-2 bg-orange-600 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-orange-700 hover:shadow-lg focus:bg-orange-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-orange-800 active:shadow-lg transition duration-150 ease-in-out"
            >
            Send A Quote
          </button>
                </div>
            <div className="md:hidden block text-lg "> 
             {'>'} 
                </div>
            </div >
            <div className="font-bold">Fixed Price | $1k-$2.5k</div>
            <div>{description}</div>
            <div className="flex flex-wrap my-2 ">
                {
                    tags && tags.map((t,index)=>{
                        return <Link  key={index} href={`/assignments/tags/${t}`}><div className="border-2 border-orange-300 rounded w-fit p-1 mr-2 cursor-pointer">{t}</div></Link>
                    })
                }
            </div>
            <div className="flex items-center  border-t-2  pt-3">
            <div className="h-16 w-16 rounded-full overflow-hidden  ">
                <img className="w-full h-full" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAM1BMVEXk5ueutLfn6eqrsbTp6+zg4uOwtrnJzc/j5earsbW0uby4vcDQ09XGyszU19jd3+G/xMamCvwDAAAFLklEQVR4nO2d2bLbIAxAbYE3sDH//7WFbPfexG4MiCAcnWmnrzkjIRaD2jQMwzAMwzAMwzAMwzAMwzAMwzAMwzAMwzAMwzAMw5wQkHJczewxZh2lhNK/CBOQo1n0JIT74/H/qMV0Z7GU3aCcVPuEE1XDCtVLAhgtpme7H0s1N1U7QjO0L8F7llzGeh1hEG/8Lo7TUmmuSrOfns9xnGXpXxsONPpA/B6OqqstjC6Ax/0ujkNdYQQbKNi2k64qiiEZ+ohi35X+2YcZw/WujmslYewiAliVYrxgJYrdwUmwXsU+RdApUi83oNIE27YvrfB/ZPg8+BJETXnqh9CVzBbTQHgojgiCvtqU9thFJg/CKz3VIMKMEkIXxIWqIpIg2SkjYj+xC816mrJae2aiWGykxRNsW0UwiJghJDljYI5CD8GRiCtIsJxizYUPQ2pzItZy5pcisTRdk/a9m4amtNNfBuQkdVhSaYqfpNTSFGfb9GRIakrE2Pm+GFLaCQPqiu0OpWP+HMPQQcgQMiQprWXNmsVwIjQjYi/ZrhAqNTCgr2gu0Jnz85RSSjso0HkMFZ0YZjKkc26a/jlmh9JiDyDxi9oeorTYAzZkwwoMz19pzj9bnH/GP/+qbchjSGflneWYhtTuKdMOmNKZcJ5TjInQKcYXnESd/jQxy0ENpULTNGOGgxpap/oyw9pbUAqhfx2Dbkhovvfgz4iUzoM9+GlK6/Mh4q29hyC1mwro30hpVVLPF9wYQr71RazOeM5/cw81iBRD+A03aM9/C/obbrKjbYSpCmIVG3qT/Q8oeUo3Rz0IL7vI1tEbCB9pSiu8I/aV8x3Kg/BGWrWp4ZVs0nZfmAoEG4h/61yHYIJiFSl6Q0Vk6tTW1N8kYp8hdOkfHYYMXd2Qft+8CYwqYDSKvqIh+MCF8Wgca2u/cwdgeW3TtuVn6+1oBs3yLo5C2JpK6CvQzGpfUkz9UG/87gCsi5o2LIXolxN0FbwAsjOLEr+YJmXn7iR6N0BCt5p5cMxm7eAsfS+/CACQf4CTpKjzgkvr2cVarVTf96372yut7XLJ1sa7lv6VcfgYrWaxqr3Wlo1S6pvStr22sxOtTNPLzdY3nj20bPP+ejFdJYkLsjGLdtPBEbe/mr2bQKiXWJDroA+vtzc0p9aahuwqHMDYrQEXHEw9jwQl3drMpts9JBU1SdktPe5FBRdJQ6bwXBpa57ib2A8kukQDzMjh++Uo7Fo6Wd02Pkf4fknqoo4HtvAIjsqUcjx6DIPgWCaOML9rKI/oqD9/lgNrn+eF+p7j8tnzHBiR7+kdUGw/+V1Kzkc75mMy6U+FMaxjPibiM1U1uGM+puInHpmALZCgP4pt7i840MV8+0R1zPsRB6UTcqpizncYwZ89syDydfyWCwXB1l8/zRNGWbTG/GHKUm9AkxHMc/EGSk3z2+ArEhPEV5TUBLEvUGFcjEUH80J/jveTGOAJEljJbILWGQT3zRYiwuKsUXN1EEJAzBhRJFll7mBUG7KD8EqPkKekBREaL8hMDZLQSG6AQjtHPYmvTQnX0TtpC1SYCe2YdkkyLP3jj5BSbKiuR585eQhTgoje6yIb0Yb0C+mV6EYvebqw5SDy2WmubogZiF2AVxPC2FpDf8H2Q9QWo6IkjUxTWVEI3WY/wrCeSuqJ+eRWzXR/JXwgVjUMozbCOfoEZiSiKVGepqv5CJ8RyR4D7xBeamqa7z3BJ/z17JxuBPdv93d/a2Ki878MMAzDMAzDMAzDMAzDMF/KP09VUmxBAiI3AAAAAElFTkSuQmCC"/>
                </div>
            <div className="ml-5 font-bold">{postedBy}</div>
                
            </div>
        </div> 
                </div>
                    </Link>
                    </>
    )
}
export default Assignment;