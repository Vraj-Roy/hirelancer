
const About=()=>{
    return(
        <div className=""> Freelancers  </div>
    )
}
export default About;