const Solutions =()=>{
    return(
        <>
        Solutions
        </>
    )
}
export default Solutions;