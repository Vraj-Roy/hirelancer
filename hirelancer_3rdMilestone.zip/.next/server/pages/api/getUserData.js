"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/getUserData";
exports.ids = ["pages/api/getUserData"];
exports.modules = {

/***/ "jsonwebtoken":
/*!*******************************!*\
  !*** external "jsonwebtoken" ***!
  \*******************************/
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "(api)/./middleware/db.js":
/*!**************************!*\
  !*** ./middleware/db.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst connectDb = async ()=>{\n    if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connections[0].readyState)) {\n        return;\n    }\n    mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(\"mongodb://localhost:27017/hirelancer\").then(()=>console.log(\"Database connected!\")\n    ).catch((err)=>console.log(err)\n    );\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (connectDb);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9taWRkbGV3YXJlL2RiLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFnQztBQUVoQyxNQUFPQyxTQUFTLEdBQUcsVUFBUztJQUN4QixJQUFHRCwyRUFBa0MsRUFBQztRQUNsQyxPQUFPO0tBQ1Y7SUFDRUEsdURBQWdCLENBQUNLLHNDQUFrQixDQUFDLENBQUNHLElBQUksQ0FBQyxJQUFNQyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQztJQUFBLENBQUMsQ0FDbEZDLEtBQUssQ0FBQ0MsQ0FBQUEsR0FBRyxHQUFJSCxPQUFPLENBQUNDLEdBQUcsQ0FBQ0UsR0FBRyxDQUFDO0lBQUEsQ0FBQyxDQUFDO0NBSWxDO0FBQ0wsaUVBQWVYLFNBQVMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9oaXJlbGFuY2VyLy4vbWlkZGxld2FyZS9kYi5qcz80MzcyIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBtb25nb29zZSBmcm9tIFwibW9uZ29vc2VcIjtcclxuXHJcbmNvbnN0ICBjb25uZWN0RGIgPSBhc3luYygpPT57IFxyXG4gICAgaWYobW9uZ29vc2UuY29ubmVjdGlvbnNbMF0ucmVhZHlTdGF0ZSl7ICBcclxuICAgICAgICByZXR1cm47XHJcbiAgICB9IFxyXG4gICAgICAgbW9uZ29vc2UuY29ubmVjdChwcm9jZXNzLmVudi5EQl9VUkkpLnRoZW4oKCkgPT4gY29uc29sZS5sb2coXCJEYXRhYmFzZSBjb25uZWN0ZWQhXCIpKVxyXG4gICAgICAgLmNhdGNoKGVyciA9PiBjb25zb2xlLmxvZyhlcnIpKTtcclxuICAgICAgICBcclxuXHJcblxyXG4gICAgfVxyXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0RGIiXSwibmFtZXMiOlsibW9uZ29vc2UiLCJjb25uZWN0RGIiLCJjb25uZWN0aW9ucyIsInJlYWR5U3RhdGUiLCJjb25uZWN0IiwicHJvY2VzcyIsImVudiIsIkRCX1VSSSIsInRoZW4iLCJjb25zb2xlIiwibG9nIiwiY2F0Y2giLCJlcnIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./middleware/db.js\n");

/***/ }),

/***/ "(api)/./models/User.js":
/*!************************!*\
  !*** ./models/User.js ***!
  \************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("\nvar mongoose = __webpack_require__(/*! mongoose */ \"mongoose\");\nconst UserSchema = mongoose.Schema({\n    email: {\n        type: String,\n        unique: true\n    },\n    username: {\n        type: String,\n        unique: true\n    },\n    password: {\n        type: String\n    },\n    profile_pic: {\n        type: String,\n        default: \"/profile\"\n    },\n    about: {\n        type: String,\n        default: \"\"\n    },\n    firstName: {\n        type: String,\n        default: \"\"\n    },\n    lastName: {\n        type: String,\n        default: \"\"\n    },\n    phone: {\n        type: String,\n        default: \"\"\n    },\n    country: {\n        type: String,\n        default: \"\"\n    },\n    role: {\n        type: String,\n        default: \"\"\n    }\n});\nmongoose.models = {};\nmodule.exports = mongoose.model(\"User\", UserSchema);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9tb2RlbHMvVXNlci5qcy5qcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUFBLElBQUlBLFFBQVEsR0FBR0MsbUJBQU8sQ0FBRSwwQkFBVSxDQUFDO0FBRW5DLE1BQU1DLFVBQVUsR0FBR0YsUUFBUSxDQUFDRyxNQUFNLENBQUM7SUFDL0JDLEtBQUssRUFBRztRQUFDQyxJQUFJLEVBQUNDLE1BQU07UUFBRUMsTUFBTSxFQUFDLElBQUk7S0FBQztJQUNsQ0MsUUFBUSxFQUFDO1FBQUNILElBQUksRUFBQ0MsTUFBTTtRQUFHQyxNQUFNLEVBQUMsSUFBSTtLQUFDO0lBQ3BDRSxRQUFRLEVBQUM7UUFBQ0osSUFBSSxFQUFDQyxNQUFNO0tBQUM7SUFDdEJJLFdBQVcsRUFBQztRQUFDTCxJQUFJLEVBQUNDLE1BQU07UUFBQ0ssT0FBTyxFQUFDLFVBQVU7S0FBQztJQUM1Q0MsS0FBSyxFQUFDO1FBQUNQLElBQUksRUFBQ0MsTUFBTTtRQUFDSyxPQUFPLEVBQUMsRUFBRTtLQUFDO0lBQzlCRSxTQUFTLEVBQUM7UUFBQ1IsSUFBSSxFQUFDQyxNQUFNO1FBQUNLLE9BQU8sRUFBQyxFQUFFO0tBQUM7SUFDbENHLFFBQVEsRUFBQztRQUFDVCxJQUFJLEVBQUNDLE1BQU07UUFBQ0ssT0FBTyxFQUFDLEVBQUU7S0FBQztJQUNqQ0ksS0FBSyxFQUFDO1FBQUNWLElBQUksRUFBQ0MsTUFBTTtRQUFDSyxPQUFPLEVBQUMsRUFBRTtLQUFDO0lBQzlCSyxPQUFPLEVBQUM7UUFBQ1gsSUFBSSxFQUFDQyxNQUFNO1FBQUNLLE9BQU8sRUFBQyxFQUFFO0tBQUM7SUFDaENNLElBQUksRUFBQztRQUFDWixJQUFJLEVBQUNDLE1BQU07UUFBQ0ssT0FBTyxFQUFDLEVBQUU7S0FBQztDQUNoQyxDQUFDO0FBQ0ZYLFFBQVEsQ0FBQ2tCLE1BQU0sR0FBQyxFQUFFO0FBQ2xCQyxNQUFNLENBQUNDLE9BQU8sR0FBR3BCLFFBQVEsQ0FBQ3FCLEtBQUssQ0FBQyxNQUFNLEVBQUNuQixVQUFVLENBQUMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2hpcmVsYW5jZXIvLi9tb2RlbHMvVXNlci5qcz83MzY3Il0sInNvdXJjZXNDb250ZW50IjpbInZhciBtb25nb29zZSA9IHJlcXVpcmUgKCdtb25nb29zZScpXHJcblxyXG5jb25zdCBVc2VyU2NoZW1hID0gbW9uZ29vc2UuU2NoZW1hKHsgXHJcbiAgICBlbWFpbCA6IHt0eXBlOlN0cmluZyAsdW5pcXVlOnRydWV9LFxyXG4gICAgdXNlcm5hbWU6e3R5cGU6U3RyaW5nICwgdW5pcXVlOnRydWV9LCAgIFxyXG4gICAgcGFzc3dvcmQ6e3R5cGU6U3RyaW5nfSwgICBcclxuICAgIHByb2ZpbGVfcGljOnt0eXBlOlN0cmluZyxkZWZhdWx0OlwiL3Byb2ZpbGVcIn0gLFxyXG4gICAgYWJvdXQ6e3R5cGU6U3RyaW5nLGRlZmF1bHQ6XCJcIn0sICAgXHJcbiAgICBmaXJzdE5hbWU6e3R5cGU6U3RyaW5nLGRlZmF1bHQ6XCJcIn0sICAgXHJcbiAgICBsYXN0TmFtZTp7dHlwZTpTdHJpbmcsZGVmYXVsdDpcIlwifSwgICAgXHJcbiAgICBwaG9uZTp7dHlwZTpTdHJpbmcsZGVmYXVsdDpcIlwifSwgICBcclxuICAgIGNvdW50cnk6e3R5cGU6U3RyaW5nLGRlZmF1bHQ6XCJcIn0sICAgIFxyXG4gICAgcm9sZTp7dHlwZTpTdHJpbmcsZGVmYXVsdDpcIlwifSwgICAgXHJcbn0pIFxyXG5tb25nb29zZS5tb2RlbHM9e31cclxubW9kdWxlLmV4cG9ydHM9ICBtb25nb29zZS5tb2RlbCgnVXNlcicsVXNlclNjaGVtYSk7Il0sIm5hbWVzIjpbIm1vbmdvb3NlIiwicmVxdWlyZSIsIlVzZXJTY2hlbWEiLCJTY2hlbWEiLCJlbWFpbCIsInR5cGUiLCJTdHJpbmciLCJ1bmlxdWUiLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwicHJvZmlsZV9waWMiLCJkZWZhdWx0IiwiYWJvdXQiLCJmaXJzdE5hbWUiLCJsYXN0TmFtZSIsInBob25lIiwiY291bnRyeSIsInJvbGUiLCJtb2RlbHMiLCJtb2R1bGUiLCJleHBvcnRzIiwibW9kZWwiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./models/User.js\n");

/***/ }),

/***/ "(api)/./pages/api/getUserData.js":
/*!**********************************!*\
  !*** ./pages/api/getUserData.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _models_User__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../models/User */ \"(api)/./models/User.js\");\n/* harmony import */ var _models_User__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_models_User__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _middleware_db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../middleware/db */ \"(api)/./middleware/db.js\");\n\nconst jwt = __webpack_require__(/*! jsonwebtoken */ \"jsonwebtoken\");\n\nconst getuserdata = async (req, res)=>{\n    await (0,_middleware_db__WEBPACK_IMPORTED_MODULE_1__[\"default\"])();\n    if (req.body.token) {\n        let user = jwt.verify(req.body.token, \"!@#$%^&*()_+KingInTheNorth!@#$%^&*()_+\");\n        if (user) {\n            let u = await _models_User__WEBPACK_IMPORTED_MODULE_0___default().findOne({\n                email: user.email\n            });\n            if (u) {\n                res.json({\n                    success: true,\n                    username: u.username,\n                    profile: u.profile_pic,\n                    role: u.role\n                });\n            } else {\n                res.json({\n                    success: false,\n                    message: \"user not found \"\n                });\n            }\n        } else {\n            res.json({\n                success: false\n            });\n        }\n    }\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getuserdata);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ2V0VXNlckRhdGEuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFxQztBQUNyQyxNQUFNQyxHQUFHLEdBQUdDLG1CQUFPLENBQUMsa0NBQWMsQ0FBQztBQUNXO0FBRTlDLE1BQU1FLFdBQVcsR0FBQyxPQUFNQyxHQUFHLEVBQUNDLEdBQUcsR0FBRztJQUc5QixNQUFNSCwwREFBUyxFQUFFLENBQUM7SUFDbEIsSUFBR0UsR0FBRyxDQUFDRSxJQUFJLENBQUNDLEtBQUssRUFBQztRQUVWLElBQUlDLElBQUksR0FBR1IsR0FBRyxDQUFDUyxNQUFNLENBQUNMLEdBQUcsQ0FBQ0UsSUFBSSxDQUFDQyxLQUFLLEVBQUMsd0NBQXdDLENBQUM7UUFDdEUsSUFBR0MsSUFBSSxFQUFDO1lBQ0osSUFBSUUsQ0FBQyxHQUFHLE1BQU1YLDJEQUFZLENBQUM7Z0JBQUNhLEtBQUssRUFBQ0osSUFBSSxDQUFDSSxLQUFLO2FBQUMsQ0FBQztZQUNsRCxJQUFHRixDQUFDLEVBQUM7Z0JBQ0RMLEdBQUcsQ0FBQ1EsSUFBSSxDQUFDO29CQUFDQyxPQUFPLEVBQUMsSUFBSTtvQkFDdEJDLFFBQVEsRUFBQ0wsQ0FBQyxDQUFDSyxRQUFRO29CQUNuQkMsT0FBTyxFQUFDTixDQUFDLENBQUNPLFdBQVc7b0JBQ3JCQyxJQUFJLEVBQUNSLENBQUMsQ0FBQ1EsSUFBSTtpQkFDbEIsQ0FBQzthQUVHLE1BQUk7Z0JBQ0RiLEdBQUcsQ0FBQ1EsSUFBSSxDQUFDO29CQUFDQyxPQUFPLEVBQUMsS0FBSztvQkFBQ0ssT0FBTyxFQUFDLGlCQUFpQjtpQkFBQyxDQUFDO2FBQ3REO1NBQ0EsTUFDRztZQUNBZCxHQUFHLENBQUNRLElBQUksQ0FBQztnQkFBQ0MsT0FBTyxFQUFDLEtBQUs7YUFBQyxDQUFDO1NBQzVCO0tBQ1o7Q0FFUjtBQUNELGlFQUFlWCxXQUFXLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9oaXJlbGFuY2VyLy4vcGFnZXMvYXBpL2dldFVzZXJEYXRhLmpzPzZjYjciXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFVzZXIgZnJvbSBcIi4uLy4uL21vZGVscy9Vc2VyXCI7IFxyXG5jb25zdCBqd3QgPSByZXF1aXJlKFwianNvbndlYnRva2VuXCIpOyBcclxuaW1wb3J0IGNvbm5lY3REYiBmcm9tICcuLy4uLy4uL21pZGRsZXdhcmUvZGInOyBcclxuXHJcbmNvbnN0IGdldHVzZXJkYXRhPWFzeW5jKHJlcSxyZXMpPT57XHJcbiAgICBcclxuICAgIFxyXG4gICAgYXdhaXQgY29ubmVjdERiKCk7ICBcclxuICAgIGlmKHJlcS5ib2R5LnRva2VuKXtcclxuICAgICAgICBcclxuICAgICAgICAgICAgbGV0IHVzZXIgPSBqd3QudmVyaWZ5KHJlcS5ib2R5LnRva2VuLCchQCMkJV4mKigpXytLaW5nSW5UaGVOb3J0aCFAIyQlXiYqKClfKycpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKHVzZXIpeyBcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHUgPSBhd2FpdCBVc2VyLmZpbmRPbmUoe2VtYWlsOnVzZXIuZW1haWx9KTsgXHJcbiAgICAgICAgICAgICAgICAgICAgaWYodSl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcy5qc29uKHtzdWNjZXNzOnRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJuYW1lOnUudXNlcm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb2ZpbGU6dS5wcm9maWxlX3BpYyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcm9sZTp1LnJvbGVcclxuICAgICAgICAgICAgICAgIH0pICBcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcy5qc29uKHtzdWNjZXNzOmZhbHNlLG1lc3NhZ2U6XCJ1c2VyIG5vdCBmb3VuZCBcIn0pIFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9IFxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcy5qc29uKHtzdWNjZXNzOmZhbHNlfSkgXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gXHJcbiAgICBcclxufVxyXG5leHBvcnQgZGVmYXVsdCBnZXR1c2VyZGF0YTsiXSwibmFtZXMiOlsiVXNlciIsImp3dCIsInJlcXVpcmUiLCJjb25uZWN0RGIiLCJnZXR1c2VyZGF0YSIsInJlcSIsInJlcyIsImJvZHkiLCJ0b2tlbiIsInVzZXIiLCJ2ZXJpZnkiLCJ1IiwiZmluZE9uZSIsImVtYWlsIiwianNvbiIsInN1Y2Nlc3MiLCJ1c2VybmFtZSIsInByb2ZpbGUiLCJwcm9maWxlX3BpYyIsInJvbGUiLCJtZXNzYWdlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/getUserData.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/getUserData.js"));
module.exports = __webpack_exports__;

})();