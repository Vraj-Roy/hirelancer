"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/getSpecicPost";
exports.ids = ["pages/api/getSpecicPost"];
exports.modules = {

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "(api)/./middleware/db.js":
/*!**************************!*\
  !*** ./middleware/db.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst connectDb = async ()=>{\n    if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connections[0].readyState)) {\n        return;\n    }\n    mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(\"mongodb://localhost:27017/hirelancer\").then(()=>console.log(\"Database connected!\")\n    ).catch((err)=>console.log(err)\n    );\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (connectDb);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9taWRkbGV3YXJlL2RiLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFnQztBQUVoQyxNQUFPQyxTQUFTLEdBQUcsVUFBUztJQUN4QixJQUFHRCwyRUFBa0MsRUFBQztRQUNsQyxPQUFPO0tBQ1Y7SUFDRUEsdURBQWdCLENBQUNLLHNDQUFrQixDQUFDLENBQUNHLElBQUksQ0FBQyxJQUFNQyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQztJQUFBLENBQUMsQ0FDbEZDLEtBQUssQ0FBQ0MsQ0FBQUEsR0FBRyxHQUFJSCxPQUFPLENBQUNDLEdBQUcsQ0FBQ0UsR0FBRyxDQUFDO0lBQUEsQ0FBQyxDQUFDO0NBSWxDO0FBQ0wsaUVBQWVYLFNBQVMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9oaXJlbGFuY2VyLy4vbWlkZGxld2FyZS9kYi5qcz80MzcyIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBtb25nb29zZSBmcm9tIFwibW9uZ29vc2VcIjtcclxuXHJcbmNvbnN0ICBjb25uZWN0RGIgPSBhc3luYygpPT57IFxyXG4gICAgaWYobW9uZ29vc2UuY29ubmVjdGlvbnNbMF0ucmVhZHlTdGF0ZSl7ICBcclxuICAgICAgICByZXR1cm47XHJcbiAgICB9IFxyXG4gICAgICAgbW9uZ29vc2UuY29ubmVjdChwcm9jZXNzLmVudi5EQl9VUkkpLnRoZW4oKCkgPT4gY29uc29sZS5sb2coXCJEYXRhYmFzZSBjb25uZWN0ZWQhXCIpKVxyXG4gICAgICAgLmNhdGNoKGVyciA9PiBjb25zb2xlLmxvZyhlcnIpKTtcclxuICAgICAgICBcclxuXHJcblxyXG4gICAgfVxyXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0RGIiXSwibmFtZXMiOlsibW9uZ29vc2UiLCJjb25uZWN0RGIiLCJjb25uZWN0aW9ucyIsInJlYWR5U3RhdGUiLCJjb25uZWN0IiwicHJvY2VzcyIsImVudiIsIkRCX1VSSSIsInRoZW4iLCJjb25zb2xlIiwibG9nIiwiY2F0Y2giLCJlcnIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./middleware/db.js\n");

/***/ }),

/***/ "(api)/./models/Assignment.js":
/*!******************************!*\
  !*** ./models/Assignment.js ***!
  \******************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("\nconst mongoose = __webpack_require__(/*! mongoose */ \"mongoose\");\nconst assignmentSchema = mongoose.Schema({\n    assignmentName: {\n        type: String\n    },\n    dueDate: {\n        type: String\n    },\n    dueTime: {\n        type: String\n    },\n    timeZone: {\n        type: String\n    },\n    description: {\n        type: String\n    },\n    tags: {\n        type: Array\n    },\n    postedBy: {\n        type: String\n    },\n    slug: {\n        type: String\n    },\n    postedOn: {\n        type: String,\n        default: Date.now()\n    }\n});\nmongoose.models = {};\nmodule.exports = mongoose.model(\"Assignment\", assignmentSchema);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9tb2RlbHMvQXNzaWdubWVudC5qcy5qcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQU1BLFFBQVEsR0FBRUMsbUJBQU8sQ0FBQywwQkFBVSxDQUFDO0FBRW5DLE1BQU1DLGdCQUFnQixHQUFHRixRQUFRLENBQUNHLE1BQU0sQ0FBQztJQUNyQ0MsY0FBYyxFQUFDO1FBQUNDLElBQUksRUFBQ0MsTUFBTTtLQUFDO0lBQzVCQyxPQUFPLEVBQUM7UUFBQ0YsSUFBSSxFQUFDQyxNQUFNO0tBQUM7SUFDckJFLE9BQU8sRUFBQztRQUFDSCxJQUFJLEVBQUNDLE1BQU07S0FBQztJQUNyQkcsUUFBUSxFQUFDO1FBQUNKLElBQUksRUFBQ0MsTUFBTTtLQUFDO0lBQ3RCSSxXQUFXLEVBQUM7UUFBQ0wsSUFBSSxFQUFDQyxNQUFNO0tBQUM7SUFDekJLLElBQUksRUFBQztRQUFDTixJQUFJLEVBQUNPLEtBQUs7S0FBQztJQUNqQkMsUUFBUSxFQUFDO1FBQUNSLElBQUksRUFBQ0MsTUFBTTtLQUFFO0lBQ3ZCUSxJQUFJLEVBQUM7UUFBQ1QsSUFBSSxFQUFDQyxNQUFNO0tBQUU7SUFDbkJTLFFBQVEsRUFBQztRQUFDVixJQUFJLEVBQUNDLE1BQU07UUFBRVUsT0FBTyxFQUFDQyxJQUFJLENBQUNDLEdBQUcsRUFBRTtLQUFFO0NBQzlDLENBQUM7QUFFRmxCLFFBQVEsQ0FBQ21CLE1BQU0sR0FBQyxFQUFFLENBQUM7QUFDbkJDLE1BQU0sQ0FBQ0MsT0FBTyxHQUFDckIsUUFBUSxDQUFDc0IsS0FBSyxDQUFDLFlBQVksRUFBQ3BCLGdCQUFnQixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vaGlyZWxhbmNlci8uL21vZGVscy9Bc3NpZ25tZW50LmpzPzUwYzYiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgbW9uZ29vc2U9IHJlcXVpcmUoJ21vbmdvb3NlJyk7XHJcblxyXG5jb25zdCBhc3NpZ25tZW50U2NoZW1hID0gbW9uZ29vc2UuU2NoZW1hKHsgXHJcbiAgICBhc3NpZ25tZW50TmFtZTp7dHlwZTpTdHJpbmd9LCAgXHJcbiAgICBkdWVEYXRlOnt0eXBlOlN0cmluZ30sXHJcbiAgICBkdWVUaW1lOnt0eXBlOlN0cmluZ30sXHJcbiAgICB0aW1lWm9uZTp7dHlwZTpTdHJpbmd9LFxyXG4gICAgZGVzY3JpcHRpb246e3R5cGU6U3RyaW5nfSxcclxuICAgIHRhZ3M6e3R5cGU6QXJyYXl9LFxyXG4gICAgcG9zdGVkQnk6e3R5cGU6U3RyaW5nLH0sXHJcbiAgICBzbHVnOnt0eXBlOlN0cmluZyx9LFxyXG4gICAgcG9zdGVkT246e3R5cGU6U3RyaW5nLCBkZWZhdWx0OkRhdGUubm93KCkgfVxyXG59KVxyXG4gICAgXHJcbm1vbmdvb3NlLm1vZGVscz17fTtcclxubW9kdWxlLmV4cG9ydHM9bW9uZ29vc2UubW9kZWwoJ0Fzc2lnbm1lbnQnLGFzc2lnbm1lbnRTY2hlbWEpIl0sIm5hbWVzIjpbIm1vbmdvb3NlIiwicmVxdWlyZSIsImFzc2lnbm1lbnRTY2hlbWEiLCJTY2hlbWEiLCJhc3NpZ25tZW50TmFtZSIsInR5cGUiLCJTdHJpbmciLCJkdWVEYXRlIiwiZHVlVGltZSIsInRpbWVab25lIiwiZGVzY3JpcHRpb24iLCJ0YWdzIiwiQXJyYXkiLCJwb3N0ZWRCeSIsInNsdWciLCJwb3N0ZWRPbiIsImRlZmF1bHQiLCJEYXRlIiwibm93IiwibW9kZWxzIiwibW9kdWxlIiwiZXhwb3J0cyIsIm1vZGVsIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./models/Assignment.js\n");

/***/ }),

/***/ "(api)/./pages/api/getSpecicPost.js":
/*!************************************!*\
  !*** ./pages/api/getSpecicPost.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _models_Assignment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../models/Assignment */ \"(api)/./models/Assignment.js\");\n/* harmony import */ var _models_Assignment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_models_Assignment__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _middleware_db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../middleware/db */ \"(api)/./middleware/db.js\");\n\n\nconst getSpecicPost = async (req, res)=>{\n    await (0,_middleware_db__WEBPACK_IMPORTED_MODULE_1__[\"default\"])();\n    let A = await _models_Assignment__WEBPACK_IMPORTED_MODULE_0___default().findOne({\n        slug: req.body.slug\n    });\n    res.json(A);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getSpecicPost);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ2V0U3BlY2ljUG9zdC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQWlEO0FBQ047QUFDM0MsTUFBTUUsYUFBYSxHQUFHLE9BQU1DLEdBQUcsRUFBQ0MsR0FBRyxHQUFLO0lBRXBDLE1BQU1ILDBEQUFTLEVBQUUsQ0FBQztJQUNsQixJQUFJSSxDQUFDLEdBQUUsTUFBTUwsaUVBQW1CLENBQUM7UUFDN0JPLElBQUksRUFBQ0osR0FBRyxDQUFDSyxJQUFJLENBQUNELElBQUk7S0FDckIsQ0FBQztJQUNGSCxHQUFHLENBQUNLLElBQUksQ0FBQ0osQ0FBQyxDQUFDO0NBRWQ7QUFFRCxpRUFBZUgsYUFBYSIsInNvdXJjZXMiOlsid2VicGFjazovL2hpcmVsYW5jZXIvLi9wYWdlcy9hcGkvZ2V0U3BlY2ljUG9zdC5qcz9iNDhjIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBBc3NpZ25tZW50cyBmcm9tIFwiLi4vLi4vbW9kZWxzL0Fzc2lnbm1lbnRcIlxyXG5pbXBvcnQgY29ubmVjdERiIGZyb20gXCIuLi8uLi9taWRkbGV3YXJlL2RiXCJcclxuY29uc3QgZ2V0U3BlY2ljUG9zdCA9IGFzeW5jKHJlcSxyZXMpID0+IHsgXHJcblxyXG4gICAgYXdhaXQgY29ubmVjdERiKCk7XHJcbiAgICBsZXQgQT0gYXdhaXQgQXNzaWdubWVudHMuZmluZE9uZSh7XHJcbiAgICAgICAgc2x1ZzpyZXEuYm9keS5zbHVnXHJcbiAgICB9KVxyXG4gICAgcmVzLmpzb24oQSlcclxuICAgIFxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBnZXRTcGVjaWNQb3N0Il0sIm5hbWVzIjpbIkFzc2lnbm1lbnRzIiwiY29ubmVjdERiIiwiZ2V0U3BlY2ljUG9zdCIsInJlcSIsInJlcyIsIkEiLCJmaW5kT25lIiwic2x1ZyIsImJvZHkiLCJqc29uIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/getSpecicPost.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/getSpecicPost.js"));
module.exports = __webpack_exports__;

})();