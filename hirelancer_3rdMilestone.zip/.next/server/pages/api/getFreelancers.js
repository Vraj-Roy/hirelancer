"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/getFreelancers";
exports.ids = ["pages/api/getFreelancers"];
exports.modules = {

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "(api)/./middleware/db.js":
/*!**************************!*\
  !*** ./middleware/db.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst connectDb = async ()=>{\n    if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connections[0].readyState)) {\n        return;\n    }\n    mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(\"mongodb://localhost:27017/hirelancer\").then(()=>console.log(\"Database connected!\")\n    ).catch((err)=>console.log(err)\n    );\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (connectDb);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9taWRkbGV3YXJlL2RiLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFnQztBQUVoQyxNQUFPQyxTQUFTLEdBQUcsVUFBUztJQUN4QixJQUFHRCwyRUFBa0MsRUFBQztRQUNsQyxPQUFPO0tBQ1Y7SUFDRUEsdURBQWdCLENBQUNLLHNDQUFrQixDQUFDLENBQUNHLElBQUksQ0FBQyxJQUFNQyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQztJQUFBLENBQUMsQ0FDbEZDLEtBQUssQ0FBQ0MsQ0FBQUEsR0FBRyxHQUFJSCxPQUFPLENBQUNDLEdBQUcsQ0FBQ0UsR0FBRyxDQUFDO0lBQUEsQ0FBQyxDQUFDO0NBSWxDO0FBQ0wsaUVBQWVYLFNBQVMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9oaXJlbGFuY2VyLy4vbWlkZGxld2FyZS9kYi5qcz80MzcyIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBtb25nb29zZSBmcm9tIFwibW9uZ29vc2VcIjtcclxuXHJcbmNvbnN0ICBjb25uZWN0RGIgPSBhc3luYygpPT57IFxyXG4gICAgaWYobW9uZ29vc2UuY29ubmVjdGlvbnNbMF0ucmVhZHlTdGF0ZSl7ICBcclxuICAgICAgICByZXR1cm47XHJcbiAgICB9IFxyXG4gICAgICAgbW9uZ29vc2UuY29ubmVjdChwcm9jZXNzLmVudi5EQl9VUkkpLnRoZW4oKCkgPT4gY29uc29sZS5sb2coXCJEYXRhYmFzZSBjb25uZWN0ZWQhXCIpKVxyXG4gICAgICAgLmNhdGNoKGVyciA9PiBjb25zb2xlLmxvZyhlcnIpKTtcclxuICAgICAgICBcclxuXHJcblxyXG4gICAgfVxyXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0RGIiXSwibmFtZXMiOlsibW9uZ29vc2UiLCJjb25uZWN0RGIiLCJjb25uZWN0aW9ucyIsInJlYWR5U3RhdGUiLCJjb25uZWN0IiwicHJvY2VzcyIsImVudiIsIkRCX1VSSSIsInRoZW4iLCJjb25zb2xlIiwibG9nIiwiY2F0Y2giLCJlcnIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./middleware/db.js\n");

/***/ }),

/***/ "(api)/./models/FreelancerProfile.js":
/*!*************************************!*\
  !*** ./models/FreelancerProfile.js ***!
  \*************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("\nvar mongoose = __webpack_require__(/*! mongoose */ \"mongoose\");\nconst FreelancerProfileSchema = mongoose.Schema({\n    email: {\n        type: String,\n        unique: true\n    },\n    username: {\n        type: String,\n        unique: true\n    },\n    education: {\n        type: String\n    },\n    youDo: {\n        type: String\n    },\n    englishProficiency: {\n        type: String\n    },\n    skills: {\n        type: Array\n    },\n    description: {\n        type: String\n    }\n});\nmongoose.models = {};\nmodule.exports = mongoose.model(\"Freelancer\", FreelancerProfileSchema);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9tb2RlbHMvRnJlZWxhbmNlclByb2ZpbGUuanMuanMiLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxJQUFJQSxRQUFRLEdBQUdDLG1CQUFPLENBQUUsMEJBQVUsQ0FBQztBQUVuQyxNQUFNQyx1QkFBdUIsR0FBR0YsUUFBUSxDQUFDRyxNQUFNLENBQUM7SUFDNUNDLEtBQUssRUFBRztRQUFDQyxJQUFJLEVBQUNDLE1BQU07UUFBRUMsTUFBTSxFQUFDLElBQUk7S0FBQztJQUNsQ0MsUUFBUSxFQUFDO1FBQUNILElBQUksRUFBQ0MsTUFBTTtRQUFHQyxNQUFNLEVBQUMsSUFBSTtLQUFDO0lBQ3BDRSxTQUFTLEVBQUM7UUFBQ0osSUFBSSxFQUFDQyxNQUFNO0tBQUM7SUFDdkJJLEtBQUssRUFBQztRQUFDTCxJQUFJLEVBQUNDLE1BQU07S0FBQztJQUNuQkssa0JBQWtCLEVBQUM7UUFBQ04sSUFBSSxFQUFDQyxNQUFNO0tBQUM7SUFDaENNLE1BQU0sRUFBQztRQUFDUCxJQUFJLEVBQUNRLEtBQUs7S0FBQztJQUNuQkMsV0FBVyxFQUFDO1FBQUNULElBQUksRUFBQ0MsTUFBTTtLQUFDO0NBQzVCLENBQUM7QUFDRk4sUUFBUSxDQUFDZSxNQUFNLEdBQUMsRUFBRTtBQUNsQkMsTUFBTSxDQUFDQyxPQUFPLEdBQUdqQixRQUFRLENBQUNrQixLQUFLLENBQUMsWUFBWSxFQUFDaEIsdUJBQXVCLENBQUMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2hpcmVsYW5jZXIvLi9tb2RlbHMvRnJlZWxhbmNlclByb2ZpbGUuanM/MmRjOCJdLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgbW9uZ29vc2UgPSByZXF1aXJlICgnbW9uZ29vc2UnKVxyXG5cclxuY29uc3QgRnJlZWxhbmNlclByb2ZpbGVTY2hlbWEgPSBtb25nb29zZS5TY2hlbWEoeyBcclxuICAgIGVtYWlsIDoge3R5cGU6U3RyaW5nICx1bmlxdWU6dHJ1ZX0sXHJcbiAgICB1c2VybmFtZTp7dHlwZTpTdHJpbmcgLCB1bmlxdWU6dHJ1ZX0sICAgIFxyXG4gICAgZWR1Y2F0aW9uOnt0eXBlOlN0cmluZ30gLFxyXG4gICAgeW91RG86e3R5cGU6U3RyaW5nfSwgICBcclxuICAgIGVuZ2xpc2hQcm9maWNpZW5jeTp7dHlwZTpTdHJpbmd9LFxyXG4gICAgc2tpbGxzOnt0eXBlOkFycmF5fSwgIFxyXG4gICAgZGVzY3JpcHRpb246e3R5cGU6U3RyaW5nfSAgXHJcbn0pIFxyXG5tb25nb29zZS5tb2RlbHM9e31cclxubW9kdWxlLmV4cG9ydHM9ICBtb25nb29zZS5tb2RlbCgnRnJlZWxhbmNlcicsRnJlZWxhbmNlclByb2ZpbGVTY2hlbWEpOyJdLCJuYW1lcyI6WyJtb25nb29zZSIsInJlcXVpcmUiLCJGcmVlbGFuY2VyUHJvZmlsZVNjaGVtYSIsIlNjaGVtYSIsImVtYWlsIiwidHlwZSIsIlN0cmluZyIsInVuaXF1ZSIsInVzZXJuYW1lIiwiZWR1Y2F0aW9uIiwieW91RG8iLCJlbmdsaXNoUHJvZmljaWVuY3kiLCJza2lsbHMiLCJBcnJheSIsImRlc2NyaXB0aW9uIiwibW9kZWxzIiwibW9kdWxlIiwiZXhwb3J0cyIsIm1vZGVsIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./models/FreelancerProfile.js\n");

/***/ }),

/***/ "(api)/./pages/api/getFreelancers.js":
/*!*************************************!*\
  !*** ./pages/api/getFreelancers.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _models_FreelancerProfile__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../models/FreelancerProfile */ \"(api)/./models/FreelancerProfile.js\");\n/* harmony import */ var _models_FreelancerProfile__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_models_FreelancerProfile__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _middleware_db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../middleware/db */ \"(api)/./middleware/db.js\");\n\n\nconst getfreelancers = async (req, res)=>{\n    await (0,_middleware_db__WEBPACK_IMPORTED_MODULE_1__[\"default\"])();\n    let F = await _models_FreelancerProfile__WEBPACK_IMPORTED_MODULE_0___default().find();\n    res.json(F);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getfreelancers);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ2V0RnJlZWxhbmNlcnMuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUF3RDtBQUNWO0FBRTlDLE1BQU1FLGNBQWMsR0FBQyxPQUFNQyxHQUFHLEVBQUNDLEdBQUcsR0FBRztJQUNqQyxNQUFNSCwwREFBUyxFQUFFLENBQUM7SUFDbEIsSUFBSUksQ0FBQyxHQUFHLE1BQU1MLHFFQUFlLEVBQUU7SUFDL0JJLEdBQUcsQ0FBQ0csSUFBSSxDQUFDRixDQUFDLENBQUMsQ0FBQztDQUNmO0FBQ0QsaUVBQWVILGNBQWMsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2hpcmVsYW5jZXIvLi9wYWdlcy9hcGkvZ2V0RnJlZWxhbmNlcnMuanM/MWU0NSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgRnJlZWxhbmNlciBmcm9tIFwiLi4vLi4vbW9kZWxzL0ZyZWVsYW5jZXJQcm9maWxlXCI7IFxyXG5pbXBvcnQgY29ubmVjdERiIGZyb20gJy4vLi4vLi4vbWlkZGxld2FyZS9kYic7IFxyXG5cclxuY29uc3QgZ2V0ZnJlZWxhbmNlcnM9YXN5bmMocmVxLHJlcyk9PntcclxuICAgIGF3YWl0IGNvbm5lY3REYigpO1xyXG4gICAgbGV0IEYgPSBhd2FpdCBGcmVlbGFuY2VyLmZpbmQoKSBcclxuICAgIHJlcy5qc29uKEYpOyAgICAgICAgXHJcbn1cclxuZXhwb3J0IGRlZmF1bHQgZ2V0ZnJlZWxhbmNlcnM7Il0sIm5hbWVzIjpbIkZyZWVsYW5jZXIiLCJjb25uZWN0RGIiLCJnZXRmcmVlbGFuY2VycyIsInJlcSIsInJlcyIsIkYiLCJmaW5kIiwianNvbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/getFreelancers.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/getFreelancers.js"));
module.exports = __webpack_exports__;

})();