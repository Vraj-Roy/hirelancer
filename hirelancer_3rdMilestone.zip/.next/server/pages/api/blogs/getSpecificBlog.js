"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/blogs/getSpecificBlog";
exports.ids = ["pages/api/blogs/getSpecificBlog"];
exports.modules = {

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "(api)/./middleware/db.js":
/*!**************************!*\
  !*** ./middleware/db.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst connectDb = async ()=>{\n    if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connections[0].readyState)) {\n        return;\n    }\n    mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(\"mongodb://localhost:27017/hirelancer\").then(()=>console.log(\"Database connected!\")\n    ).catch((err)=>console.log(err)\n    );\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (connectDb);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9taWRkbGV3YXJlL2RiLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFnQztBQUVoQyxNQUFPQyxTQUFTLEdBQUcsVUFBUztJQUN4QixJQUFHRCwyRUFBa0MsRUFBQztRQUNsQyxPQUFPO0tBQ1Y7SUFDRUEsdURBQWdCLENBQUNLLHNDQUFrQixDQUFDLENBQUNHLElBQUksQ0FBQyxJQUFNQyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQztJQUFBLENBQUMsQ0FDbEZDLEtBQUssQ0FBQ0MsQ0FBQUEsR0FBRyxHQUFJSCxPQUFPLENBQUNDLEdBQUcsQ0FBQ0UsR0FBRyxDQUFDO0lBQUEsQ0FBQyxDQUFDO0NBSWxDO0FBQ0wsaUVBQWVYLFNBQVMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9oaXJlbGFuY2VyLy4vbWlkZGxld2FyZS9kYi5qcz80MzcyIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBtb25nb29zZSBmcm9tIFwibW9uZ29vc2VcIjtcclxuXHJcbmNvbnN0ICBjb25uZWN0RGIgPSBhc3luYygpPT57IFxyXG4gICAgaWYobW9uZ29vc2UuY29ubmVjdGlvbnNbMF0ucmVhZHlTdGF0ZSl7ICBcclxuICAgICAgICByZXR1cm47XHJcbiAgICB9IFxyXG4gICAgICAgbW9uZ29vc2UuY29ubmVjdChwcm9jZXNzLmVudi5EQl9VUkkpLnRoZW4oKCkgPT4gY29uc29sZS5sb2coXCJEYXRhYmFzZSBjb25uZWN0ZWQhXCIpKVxyXG4gICAgICAgLmNhdGNoKGVyciA9PiBjb25zb2xlLmxvZyhlcnIpKTtcclxuICAgICAgICBcclxuXHJcblxyXG4gICAgfVxyXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0RGIiXSwibmFtZXMiOlsibW9uZ29vc2UiLCJjb25uZWN0RGIiLCJjb25uZWN0aW9ucyIsInJlYWR5U3RhdGUiLCJjb25uZWN0IiwicHJvY2VzcyIsImVudiIsIkRCX1VSSSIsInRoZW4iLCJjb25zb2xlIiwibG9nIiwiY2F0Y2giLCJlcnIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./middleware/db.js\n");

/***/ }),

/***/ "(api)/./models/Blog.js":
/*!************************!*\
  !*** ./models/Blog.js ***!
  \************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("\nvar mongoose = __webpack_require__(/*! mongoose */ \"mongoose\");\nconst BlogSchema = mongoose.Schema({\n    title: {\n        type: String\n    },\n    description: {\n        type: String\n    },\n    img: {\n        type: String\n    },\n    slug: {\n        type: String\n    }\n}, {\n    timestamps: true\n});\nmongoose.models = {};\nmodule.exports = mongoose.model(\"Blog\", BlogSchema);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9tb2RlbHMvQmxvZy5qcy5qcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUFBLElBQUlBLFFBQVEsR0FBR0MsbUJBQU8sQ0FBRSwwQkFBVSxDQUFDO0FBRW5DLE1BQU1DLFVBQVUsR0FBR0YsUUFBUSxDQUFDRyxNQUFNLENBQUM7SUFDL0JDLEtBQUssRUFBRztRQUFDQyxJQUFJLEVBQUNDLE1BQU07S0FBQztJQUNyQkMsV0FBVyxFQUFHO1FBQUNGLElBQUksRUFBQ0MsTUFBTTtLQUFDO0lBQzNCRSxHQUFHLEVBQUM7UUFBQ0gsSUFBSSxFQUFDQyxNQUFNO0tBQUM7SUFDakJHLElBQUksRUFBQztRQUFDSixJQUFJLEVBQUNDLE1BQU07S0FBQztDQUNyQixFQUFDO0lBQUNJLFVBQVUsRUFBRSxJQUFJO0NBQUMsQ0FBQztBQUNyQlYsUUFBUSxDQUFDVyxNQUFNLEdBQUMsRUFBRTtBQUNsQkMsTUFBTSxDQUFDQyxPQUFPLEdBQUliLFFBQVEsQ0FBQ2MsS0FBSyxDQUFDLE1BQU0sRUFBQ1osVUFBVSxDQUFFLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9oaXJlbGFuY2VyLy4vbW9kZWxzL0Jsb2cuanM/ZGNlNiJdLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgbW9uZ29vc2UgPSByZXF1aXJlICgnbW9uZ29vc2UnKVxyXG5cclxuY29uc3QgQmxvZ1NjaGVtYSA9IG1vbmdvb3NlLlNjaGVtYSh7IFxyXG4gICAgdGl0bGUgOiB7dHlwZTpTdHJpbmd9LCBcclxuICAgIGRlc2NyaXB0aW9uIDoge3R5cGU6U3RyaW5nfSxcclxuICAgIGltZzp7dHlwZTpTdHJpbmd9LFxyXG4gICAgc2x1Zzp7dHlwZTpTdHJpbmd9LCBcclxufSx7dGltZXN0YW1wczogdHJ1ZX0pIFxyXG5tb25nb29zZS5tb2RlbHM9e31cclxubW9kdWxlLmV4cG9ydHM9ICAgbW9uZ29vc2UubW9kZWwoJ0Jsb2cnLEJsb2dTY2hlbWEgKTsiXSwibmFtZXMiOlsibW9uZ29vc2UiLCJyZXF1aXJlIiwiQmxvZ1NjaGVtYSIsIlNjaGVtYSIsInRpdGxlIiwidHlwZSIsIlN0cmluZyIsImRlc2NyaXB0aW9uIiwiaW1nIiwic2x1ZyIsInRpbWVzdGFtcHMiLCJtb2RlbHMiLCJtb2R1bGUiLCJleHBvcnRzIiwibW9kZWwiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./models/Blog.js\n");

/***/ }),

/***/ "(api)/./pages/api/blogs/getSpecificBlog.js":
/*!********************************************!*\
  !*** ./pages/api/blogs/getSpecificBlog.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _middleware_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../middleware/db */ \"(api)/./middleware/db.js\");\n/* harmony import */ var _models_Blog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../models/Blog */ \"(api)/./models/Blog.js\");\n/* harmony import */ var _models_Blog__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_models_Blog__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst getSpecificBlog = async (req, res)=>{\n    await (0,_middleware_db__WEBPACK_IMPORTED_MODULE_0__[\"default\"])();\n    let B = await _models_Blog__WEBPACK_IMPORTED_MODULE_1___default().findOne({\n        slug: req.body.slug\n    });\n    res.json(B);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getSpecificBlog);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvYmxvZ3MvZ2V0U3BlY2lmaWNCbG9nLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBK0M7QUFDUjtBQUV2QyxNQUFNRSxlQUFlLEdBQUcsT0FBTUMsR0FBRyxFQUFDQyxHQUFHLEdBQUs7SUFDdEMsTUFBTUosMERBQVMsRUFBRTtJQUNqQixJQUFJSyxDQUFDLEdBQUMsTUFBTUosMkRBQVksQ0FBQztRQUFDTSxJQUFJLEVBQUNKLEdBQUcsQ0FBQ0ssSUFBSSxDQUFDRCxJQUFJO0tBQUMsQ0FBQztJQUM5Q0gsR0FBRyxDQUFDSyxJQUFJLENBQUNKLENBQUMsQ0FBQztDQUNkO0FBRUQsaUVBQWVILGVBQWUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9oaXJlbGFuY2VyLy4vcGFnZXMvYXBpL2Jsb2dzL2dldFNwZWNpZmljQmxvZy5qcz8zMTU5Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBjb25uZWN0RGIgZnJvbSAnLi4vLi4vLi4vbWlkZGxld2FyZS9kYic7XHJcbmltcG9ydCBCbG9nIGZyb20gJy4uLy4uLy4uL21vZGVscy9CbG9nJ1xyXG5cclxuY29uc3QgZ2V0U3BlY2lmaWNCbG9nID0gYXN5bmMocmVxLHJlcykgPT4ge1xyXG4gICAgYXdhaXQgY29ubmVjdERiKClcclxuICAgIGxldCBCPWF3YWl0IEJsb2cuZmluZE9uZSh7c2x1ZzpyZXEuYm9keS5zbHVnfSkgXHJcbiAgICByZXMuanNvbihCKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBnZXRTcGVjaWZpY0Jsb2ciXSwibmFtZXMiOlsiY29ubmVjdERiIiwiQmxvZyIsImdldFNwZWNpZmljQmxvZyIsInJlcSIsInJlcyIsIkIiLCJmaW5kT25lIiwic2x1ZyIsImJvZHkiLCJqc29uIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/blogs/getSpecificBlog.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/blogs/getSpecificBlog.js"));
module.exports = __webpack_exports__;

})();